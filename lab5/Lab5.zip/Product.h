#ifndef PRODUCT_H
#define PRODUCT_H


class Product
{
    public:
        Product();
        ~Product();
        string GetProduct_name() { return Product_name; }
        void SetProduct_name(string val) { Product_name = val; }
        string GetProduct_category() { return Product_category; }
        void SetProduct_category(string val) { Product_category = val; }
        string GetProduct_description() { return Product_description; }
        void SetProduct_description(string val) { Product_description = val; }
        int Getamount_in_store() { return amount_in_store; }
        void Setamount_in_store(int val) { amount_in_store = val; }
        float Getregular_price() { return regular_price; }
        void Setregular_price(float val) { regular_price = val; }
        float Getdiscount_rate() { return discount_rate; }
        void Setdiscount_rate(float val) { discount_rate = val; }
    protected:
    private:
        string Product_name;
        string Product_category;
        string Product_description;
        int amount_in_store;
        float regular_price;
        float discount_rate;
};

#endif // PRODUCT_H
