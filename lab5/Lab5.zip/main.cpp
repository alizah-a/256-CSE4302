#include <iostream>
#include <string>
#define PRODUCT_H

using namespace std;


class Product {

private:
    string product_name;
    string product_category;
    string product_description;
    int amount_in_store;
    float regular_price;
    float discount_rate;

public:
    string get_productName(){
        return product_name;
    }
     void set_productName(string name){
        name = product_name;
    }
      string get_productCategory(){
        return product_category;
    }
     void set_productCategory(string category){
        category = product_category;
    }
      string get_productDesciption(){
        return product_description;
    }
     void set_productDescriptiom(string discrip){
        discrip = product_description;
    }
    int getamount_in_store() {
        return amount_in_store;
    }
        void setamount_in_store(int val) {
            amount_in_store = val;
    }
        float getregular_price() {
            return regular_price;
    }
        void setregular_price(float val) {
            regular_price = val;
    }
        float getdiscount_rate() {
            return discount_rate;
    }
        void setdiscount_rate(float val) {
            discount_rate = val;
    }

    bool purchase_product(int amount){

        if (amount>amount_in_store){

            cout<<"Not enough amount to purchase"<<endl;
            return false;
        }
        else
            amount_in_store = amount_in_store - amount;
            cout<<"Purchased successfully"<<endl;
            return true;
    }

    void RestockProduct(int amount){

        if(amount>0){
            amount_in_store = amount_in_store + amount;
            cout<<"Successfully restocked"<<endl;
        }
        else
            cout<<"Amount should be positive"<<endl;
    }

    int calculateDiscount(int amountOfProduct){

           float discount = 0;
           if(amountOfProduct>=5){
            discount = amountOfProduct*regular_price*discount_rate;
           }
           else if(amountOfProduct>=10){
            discount = amountOfProduct*regular_price*(discount_rate + 0.03);
           }
           return discount;
    }

    int netTotal(int amountOfProduct){
        float totalCost;
        totalCost= regular_price*amountOfProduct;
        float discount = calculateDiscount(amountOfProduct);
        int netAmount;
        netAmount = totalCost- discount;

        return netAmount;
    }

};

int main()
{
    Product pro;
    string name, discrip,category;
    int amount;
    float discount,R_price;
    pro.get_productName();
       pro.get_productDesciption();
        pro.get_productCategory();
          pro.getamount_in_store();
            pro.getregular_price();
             pro.getdiscount_rate();



    cin>>name>>category>>discrip>>amount>>R_price>>discount;

    return 0;
}

